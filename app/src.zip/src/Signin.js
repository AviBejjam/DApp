import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './styles/signin.css';

function Signin() {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleNameChange = (event) => {
    setName(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const formSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('http://localhost:3001/api/items1', { name, password });
      const userData = response.data.item;

      // Save user data in localStorage
      localStorage.setItem('user', JSON.stringify(userData));

      setMessage('User found! Redirecting...');
      // Navigate to the appropriate page based on role
      const userRole = userData.role;
      if (userRole === 'Retailer') navigate('/retailer', { state: { name } });
      else if (userRole === 'Distributor') navigate('/distributor', { state: { name } });
      else if (userRole === 'Manufacturer') navigate('/manufacturer', { state: { name } });
      else if (userRole === 'Consumer') navigate('/consumer', { state: { name } });
      else navigate('/home');
    } catch (error) {
      if (error.response && error.response.status === 404) {
        setMessage('User not found.');
      } else {
        setMessage('Failed to check user.');
      }
    }
  };

  return (
    <div className="siggnup">
      <form onSubmit={formSubmit}>
        <h1 className="textt1">SignIn</h1>
        <label className="textt1">
          Username:
          <input
            className="textt1"
            type="text"
            value={name}
            onChange={handleNameChange}
            required
          />
        </label>
        <label className="textt1">
          Password:
          <input
            className="textt1"
            type="password"
            value={password}
            onChange={handlePasswordChange}
            required
          />
        </label>
        <button type="submit">Sign In</button>
      </form>
      {message && <p>{message}</p>}
      <p className="texttt1">
        New to website <a href="/signup" className="pooo">Register?</a>
      </p>
    </div>
  );
}

export default Signin;
