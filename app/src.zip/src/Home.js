import React, { useEffect, useState } from "react";
import axios from 'axios';

function Home({ stateFilter, manufacturerFilter }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const queryParams = new URLSearchParams();
        if (stateFilter) queryParams.append('state', stateFilter);
        if (manufacturerFilter) queryParams.append('manufacturer', manufacturerFilter);

        const response = await axios.get(`http://localhost:3001/api/getItems?${queryParams.toString()}`);
        setItems(response.data);
        setLoading(false);
      } catch (error) {
        console.error('There was an error fetching the items!', error);
        setError('Could not fetch items.');
        setLoading(false);
      }
    };

    fetchItems();
  }, [stateFilter, manufacturerFilter]);

  if (loading) return <p>Loading items...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="home">
      <ul>
        {items.map(item => (
          <li key={item._id}>
            {item.productTitle && `Product Title: ${item.productTitle} | `}
            {`Quantity: ${item.quantity} | `}
            {item.cost && `Cost: ${item.cost} | `}
            {item.state && `State: ${item.state}`}
            <br />
            {item.manufacturer && `Manufacturer ~ ${item.manufacturer} | `}
            {item.distributor && `Distributor ~ ${item.distributor} | `}
            {item.retailer && `Retailer ~ ${item.retailer} | `}
            {item.consumer && `Consumer ~ ${item.consumer}`}
          </li>
        ))}
      </ul>
    </div>
  );  
}

export default Home;
