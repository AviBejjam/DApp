import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import BlockchainService, { getETHBalance } from './BlockchainService';
import axios from 'axios';
import Home from './Home';

function Manufacturer() {
  const [balance, setBalance] = useState('Loading...');
  const [user, setUser] = useState(null);
  const [productTitle, setProductTitle] = useState('');
  const [quantity, setQuantity] = useState(0);
  const [cost, setCost] = useState(0);
  const [message, setMessage] = useState('');
  const [state] = useState("Manufactured");
  const location = useLocation();
  const { name } = location.state || {}; 

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    setMessage('Processing transaction...');
  
    try {
      // Step 1: Connect to MetaMask
      const { web3, accounts } = await BlockchainService();
  
      // Manufacturer's address
      const senderAddress = user.addr;
  
      const recipientAddress = accounts[0];
  
      // Transaction details
      const transactionDetails = {
        from: senderAddress,
        to: recipientAddress,
        value: web3.utils.toWei('0.001', 'ether'), 
        gas: 21000, // Gas limit (standard for simple transactions)
      };
  
      // Step 2: Send the transaction using MetaMask
      const transaction_values = await web3.eth.sendTransaction(transactionDetails);
      console.log('Transaction Values:', transaction_values);
  
      setMessage('Transaction successful! Adding product to the database...');
  
      // Step 3: Add product to the database
      await axios.post('http://localhost:3001/api/products', {
        productTitle,
        quantity,
        cost,
        manufacturer: name,
        distributor: null,
        consumer: null,
        retailer: null,
        state,
        date: new Date(),
        tx_hash: transaction_values.transactionHash.toString(),
        from_addr: transaction_values.from,
        to_addr: transaction_values.to,
      });
  
      console.log('Product added to MongoDB');
      setMessage('Product added successfully!');
    } catch (error) {
      console.error('Transaction or Database error:', error);
      setMessage('Failed to process the transaction or add the product.');
    }
  };  

  useEffect(() => {
    const fetchBlockchainData = async () => {
      try {
        const { web3, accounts, contract } = await BlockchainService();
        if (accounts && accounts.length > 0) {
          let val = name === 'ManFac' ? 1 : name === 'ManFac_1' ? 5 : 0;
          const selectedAccount = accounts[val];
          setUser({ addr: selectedAccount, name });
          const ethBalance = await getETHBalance(selectedAccount);
          setBalance(ethBalance);
        }
      } catch (error) {
        console.error('Error fetching blockchain data:', error);
      }
    };

    fetchBlockchainData();
  }, [name]);

  return (
    <div>
      <button>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-box-arrow-left" viewBox="0 0 16 16">
          <path fillRule="evenodd" d="M6 12.5a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-8a.5.5 0 0 0-.5.5v2a.5.5 0 0 1-1 0v-2A1.5 1.5 0 0 1 6.5 2h8A1.5 1.5 0 0 1 16 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-8A1.5 1.5 0 0 1 5 12.5v-2a.5.5 0 0 1 1 0z"/>
          <path fillRule="evenodd" d="M.146 8.354a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L1.707 7.5H10.5a.5.5 0 0 1 0 1H1.707l2.147 2.146a.5.5 0 0 1-.708.708z"/>
        </svg>
        <a href="/signin">Logout</a>
      </button>

      <h1>Manufacturer</h1>
      <p>Address: {user ? user.addr : 'No address available'}</p>
      <p>Username: {user ? user.name : 'No username available'}</p>
      <p>ETH Balance: {balance} ETH</p>

      <form onSubmit={handleSubmit}>
        <label>
          Product Title:
          <input type="text" name="productTitle" value={productTitle} onChange={(e) => setProductTitle(e.target.value)} />
        </label>
        <br />
        <label>
          Product Quantity:
          <input type="number" name="quantity" value={quantity} min={0} onChange={(e) => setQuantity(e.target.value)} />
        </label>
        <br />
        <br />
        <label>
          Product Cost:     
          <input type="number" name="cost" value={cost} min={0} onChange={(e) => setCost(e.target.value)} />
        </label>
        <br />
        <button type="submit">Submit</button>
      </form>

      <h1>Manufactured Products</h1>
      <Home stateFilter="Manufactured" manufacturerFilter={[name]} />

      <div>{message}</div>
    </div>
  );
}

export default Manufacturer;
